package com.org.employee.Service.Impl;

import com.org.employee.Entity.Employee;
import com.org.employee.Repository.EmployeeRepository;
import com.org.employee.Service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }
    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }
    @Override
    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElseThrow(() -> new RuntimeException("Employee not found"));
    }
    @Override
    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

    @Override
    public List<Employee> searchEmployees(String name, String department, List<String> skills) {
        List<Employee> employees = employeeRepository.findAll();

        // Apply filters using Java Streams
        return employees.stream()
                .filter(employee -> (name == null || employee.getName().toLowerCase().contains(name.toLowerCase())))
                .filter(employee -> (department == null || employee.getDepartment().equalsIgnoreCase(department)))
                .filter(employee -> (skills == null || !Collections.disjoint(employee.getSkills(), skills)))
                .sorted(Comparator.comparing(Employee::getName))
                .collect(Collectors.toList());
    }

    @Override
    public Employee updateEmployee(Long id, String name, String email, String department, List<String> skills) {
        Employee existingEmployee = employeeRepository.findById(id).orElseThrow(() -> new RuntimeException("Employee not found"));

        Employee updatedEmployee = new Employee.EmployeeBuilder()
                .id(existingEmployee.getId())
                .name(name != null ? name : existingEmployee.getName())
                .email(email != null ? email : existingEmployee.getEmail())
                .department(department != null ? department : existingEmployee.getDepartment())
                .skills(skills != null ? skills : existingEmployee.getSkills())
                .build();

        return employeeRepository.save(updatedEmployee);
    }
}
