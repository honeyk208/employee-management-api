package com.org.employee.Util;

import com.org.employee.Entity.AuditLog;
import com.org.employee.Repository.AuditLogRepository;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;

@Aspect
@Component
public class AuditAspect {

    private static final Logger logger = LoggerFactory.getLogger(AuditAspect.class);

    @Autowired
    private AuditLogRepository auditLogRepository;

    @Pointcut("execution(* com.org.employee.*.*(..))")
    public void auditPointcut() {}

    @Before("auditPointcut()")
    public void logMethodExecution(JoinPoint joinPoint) {
        // Log the method execution details
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getSimpleName();
        Object[] args = joinPoint.getArgs();

        logger.info("Executing method: {} in class: {} with arguments: {}", methodName, className, args);

        saveAuditLog(className, methodName, args);
    }

    // This method is used to save audit logs to a file or database
    private void saveAuditLog(String className, String methodName, Object[] args) {
        AuditLog auditLog = new AuditLog();
        auditLog.setClassName(className);
        auditLog.setMethodName(methodName);
        auditLog.setArguments(Arrays.toString(args));
        auditLog.setTimestamp(LocalDateTime.now());

        // Save the audit log to the database
        auditLogRepository.save(auditLog);
    }
}
