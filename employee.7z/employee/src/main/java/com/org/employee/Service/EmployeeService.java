package com.org.employee.Service;

import com.org.employee.Entity.Employee;

import java.util.List;

public interface EmployeeService {
    Employee saveEmployee(Employee employee);

    List<Employee> getAllEmployees();

    Employee getEmployeeById(Long id);

    void deleteEmployee(Long id);

    List<Employee> searchEmployees(String name, String department, List<String> skills);

    Employee updateEmployee(Long id, String name, String email, String department, List<String> skills);
}
