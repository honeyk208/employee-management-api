package com.org.employee.ReqResp;

import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class EmployeeDTO {
    private String name;
    private String email;
    private String department;
    private List<String> skills;

}
