package com.org.employee.ReqResp;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class AuthRequest {
    private String username;
    private String password;
}

